# Task-driven completion

Status: partial. Verified real tasks: 0/27.

Primary: learned Tucker minus frozen Tucker, averaged over the four degraded validation conditions.

Average mask repeats, then seeds within participant, then participants equally.

Incomplete coverage: cohort estimates and intervals are withheld. See per-repeat and participant tables for retained evidence.

Historical and completion checkpoints reuse validation selection; no independent confirmation.

No causal recovery or architecture superiority claim.

Screening is separate from strong-control comparisons.

Incomplete real coverage suppresses cohort means; synthetic evidence is excluded.
