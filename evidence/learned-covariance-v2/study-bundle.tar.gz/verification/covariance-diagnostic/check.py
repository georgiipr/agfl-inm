"""Read-only diagnostic of fixed selected models; no fitting or selection."""
import sys,json,hashlib,tempfile,datetime,time
from pathlib import Path
from collections import defaultdict
ROOT=Path(__file__).resolve().parents[3];sys.path.insert(0,str(ROOT))
import numpy as np
import torch
from inm.task_driven_completion_cuda.execution import scoped_cuda_rng
from inm.task_driven_completion_cuda.protocol import load_config,study_identity,tasks
from inm.completion_transformer.replay import prepare_task,restore_backbones
from inm.task_driven_completion.completion import restore_completer
from inm.task_driven_completion.adapters import CompletionAdapter
from inm.task_driven_completion_cuda.training import predict

def read(p):return json.loads(Path(p).read_text())
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def ba(y,p):
    pred=p.argmax(1)
    return float(np.mean([(pred[y==k]==k).mean() for k in range(4)]))
def load_state(p):
    with np.load(p,allow_pickle=False) as a:return dict(a)

def independent_fill(raw,mask,free):
    # Independent NumPy path: solve A Z=X_O, whereas production solves for beta.
    v=np.array(free,dtype=np.float64);ii,jj=np.tril_indices(22)
    v[ii==jj]=np.logaddexp(0,v[ii==jj])+1e-6
    lower=np.zeros((22,22));lower[ii,jj]=v;sigma=lower@lower.T
    rho=.001*np.trace(sigma)/22
    safe=np.where(mask[:,:,:,None],raw,0)
    result=safe.copy()
    patterns=defaultdict(list)
    for b in range(len(raw)):
        for w in range(4):patterns[tuple(mask[b,:,w].tolist())].append((b,w))
    for flags,locations in patterns.items():
        flags=np.array(flags);o=np.flatnonzero(flags);h=np.flatnonzero(~flags)
        if not len(h):continue
        blocks=np.stack([safe[b,o,w,:] for b,w in locations])
        rhs=blocks.transpose(1,0,2).reshape(len(o),-1).astype(np.float64)
        z=np.linalg.solve(sigma[np.ix_(o,o)]+rho*np.eye(len(o)),rhs)
        yh=(sigma[np.ix_(h,o)]@z).reshape(len(h),len(locations),250).transpose(1,0,2)
        for idx,(b,w) in enumerate(locations):result[b,h,w,:]=yh[idx]
    return result

def filled_predict(backbone,filled,mask):
    # Bypass completer and adapters; explicitly feed filled inputs through frozen layers.
    outs=[]
    with torch.no_grad():
        for start in range(0,len(filled),32):
            x=torch.as_tensor(filled[start:start+32],device='cuda:0')
            z=x.reshape(len(x),22,1000).unsqueeze(1)
            for layer in ['temporal_conv','temporal_bn','spatial_conv','spatial_bn',
                'activation1','pool1','dropout1','separable_depthwise','separable_pointwise',
                'separable_bn','activation2','pool2','dropout2']:
                z=getattr(backbone,layer)(z)
            z=z.squeeze(2).transpose(1,2).contiguous()
            z=backbone.projection(z)+backbone.position_encoding.to(z)
            z=backbone.final_norm(backbone.transformer(z)).mean(1)
            flags=torch.as_tensor(mask[start:start+32],device=z.device).reshape(len(x),88).to(z.dtype)
            outs.append(backbone.classifier(torch.cat([z,flags],1)).softmax(-1).cpu().numpy())
    return np.concatenate(outs)

cfg=load_config(ROOT/'configs/task-driven-completion-cuda-v2.json',allow_existing_output=True)
out=Path(cfg['output_dir']);ident=study_identity(cfg);assert ident==read(out/'study-identity.json')
frozen_hashes=read(ROOT/'.session-runs/task-driven-completion-cuda/completion-verification/verification.json')['study_files_sha256']
assert all(sha(out/p)==h for p,h in frozen_hashes.items())
rows=[];spectra=[];checks=[];start=time.monotonic()
with scoped_cuda_rng(20261005),tempfile.TemporaryDirectory(prefix='covariance-diagnostic-') as tmp:
 for index,spec in enumerate(tasks(cfg)):
    subject,seed=spec['subject'],spec['seed'];path=out/'tasks'/f'A{subject:02d}_seed_{seed}'
    task=read(path/'task.json')
    prepared,record=prepare_task(dict(cfg,output_dir=tmp),subject,seed,Path(tmp)/f'A{subject:02d}_{seed}')
    assert set(prepared.train.sample_ids).isdisjoint(prepared.validation.sample_ids)
    raw=np.array(prepared.validation.raw,copy=True);y=prepared.validation.labels
    backbone=restore_backbones(record)['spatial_transformer'].cuda().eval().requires_grad_(False)
    init=load_state(path/'initialization.npz')
    tx=np.asarray(prepared.train.raw).transpose(0,2,3,1).reshape(-1,22).astype(np.float64)
    train_moment=tx.T@tx/len(tx)
    assert np.allclose(train_moment,init['second_moment'],rtol=1e-12,atol=1e-12)
    evals=np.linalg.eigvalsh(train_moment)[::-1];cum=np.cumsum(evals)/sum(evals)
    spectra.append({'subject':subject,'seed':seed,'top4_variance':float(cum[3]),'top8_variance':float(cum[7]),'top16_variance':float(cum[15])})
    check={'subject':subject,'seed':seed,'production_cells_replayed':0,'poison_invariant_cells':0,
       'independent_covariance_cells':0,'max_independent_probability_error':0.,'max_independent_signal_error':0.,'train_only_initialization_verified':True}
    x=torch.tensor(raw,device='cuda:0')
    for strategy in ['zero','covariance_frozen','covariance_learned','tucker_frozen','tucker_learned']:
      completer=restore_completer(strategy,load_state(path/strategy/'selected.npz')).cuda()
      adapter=CompletionAdapter(backbone,strategy,completer).eval()
      for cell in [c for c in task['cells'] if c['strategy']==strategy]:
        with np.load(path/cell['artifact'],allow_pickle=False) as a:
            mask=a['mask'];saved=a['probabilities'];labels=a['labels'];ids=a['sample_ids']
        assert np.array_equal(labels,y) and ids.tolist()==list(prepared.validation.sample_ids)
        count=22 if cell['condition']=='full_22' else int(cell['condition'].rsplit('_',1)[1])
        assert np.all(mask.sum(1)==count)
        close_ba=ba(y,saved);assert abs(close_ba-cell['balanced_accuracy'])<1e-12
        rec={'subject':subject,'seed':seed,'strategy':strategy,'condition':cell['condition'],'repeat':cell['repeat'],'ba':close_ba}
        if strategy.startswith('covariance'):
            replay=predict(adapter,x,mask);assert np.array_equal(replay,saved)
            check['production_cells_replayed']+=1
            poisoned=np.where(mask[:,:,:,None],raw,np.nan)
            pp=predict(adapter,torch.tensor(poisoned,device='cuda:0'),mask)
            assert np.array_equal(pp,saved);check['poison_invariant_cells']+=1
            alternate=independent_fill(poisoned,mask,completer.free.detach().cpu().numpy())
            if count<22:
                independent_probs=filled_predict(backbone,alternate,mask)
                pe=float(np.max(np.abs(independent_probs-saved)))
                assert np.allclose(independent_probs,saved,rtol=1e-4,atol=1e-6),(subject,seed,strategy,cell['condition'],pe)
                assert np.array_equal(independent_probs.argmax(1),saved.argmax(1))
                check['max_independent_probability_error']=max(check['max_independent_probability_error'],pe)
                check['independent_covariance_cells']+=1
        if count<22:
            with torch.no_grad():completed=completer(x,torch.tensor(mask,device=x.device)).cpu().numpy()
            assert np.array_equal(completed[mask],raw[mask])
            hidden=~np.broadcast_to(mask[:,:,:,None],raw.shape)
            err=(completed[hidden].astype(np.float64)-raw[hidden])
            rec['hidden_mse']=float(np.mean(err**2))
            rec['hidden_zero_mse']=float(np.mean(raw[hidden].astype(np.float64)**2))
            rec['reconstruction_R2_vs_zero']=1-rec['hidden_mse']/rec['hidden_zero_mse']
            if strategy.startswith('covariance'):
                se=float(np.max(np.abs(alternate-completed)))
                assert np.allclose(alternate,completed,rtol=1e-4,atol=1e-6)
                check['max_independent_signal_error']=max(check['max_independent_signal_error'],se)
        rows.append(rec)
    checks.append(check);print(json.dumps(check),flush=True)
assert all(sha(out/p)==h for p,h in frozen_hashes.items())
# Equal repeat, seed and participant weighting.
groups=defaultdict(list)
for r in rows:
 for metric in ['ba','hidden_mse','hidden_zero_mse','reconstruction_R2_vs_zero']:
  if metric in r:groups[r['subject'],r['seed'],r['strategy'],r['condition'],metric].append(r[metric])
sg={k:float(np.mean(v)) for k,v in groups.items()};groups=defaultdict(list)
for (sub,seed,st,cond,m),v in sg.items():groups[sub,st,cond,m].append(v)
pg={k:float(np.mean(v)) for k,v in groups.items()};groups=defaultdict(list)
for (sub,st,cond,m),v in pg.items():groups[st,cond,m].append(v)
cg=[{'strategy':k[0],'condition':k[1],'metric':k[2],'value':float(np.mean(v))} for k,v in groups.items()]
result={'status':'passed','study_id':ident['study_id'],'new_fits':0,'new_selection':False,
 'same_validation_trials_and_masks':True,'study_artifacts_unchanged':len(frozen_hashes),
 'elapsed_seconds':time.monotonic()-start,'verified_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'checks':checks,'training_covariance_spectra':spectra,'cohort':cg,'cells':rows,
 'participant':[{'subject':k[0],'strategy':k[1],'condition':k[2],'metric':k[3],'value':v} for k,v in pg.items()]}
Path(__file__).with_name('diagnostic.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
print(json.dumps({k:v for k,v in result.items() if k not in ['cells','participant','cohort','training_covariance_spectra','checks']},indent=2))
