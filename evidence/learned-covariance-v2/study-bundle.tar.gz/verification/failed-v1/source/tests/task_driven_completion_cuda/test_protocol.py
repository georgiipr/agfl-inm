"""Dependency-light declaration, source identity and path isolation."""
import copy
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

from inm.task_driven_completion import protocol as cpu
from inm.task_driven_completion_cuda import protocol as cuda

ROOT = Path(__file__).resolve().parents[2]
CONFIG = ROOT/'configs/task-driven-completion-cuda.json'


class ProtocolChecks(unittest.TestCase):
    def test_science_unchanged_and_execution_explicit(self):
        old,new=copy.deepcopy(cpu.FIXED['protocol']),copy.deepcopy(cuda.FIXED['protocol'])
        old.pop('execution'); execution=new.pop('execution')
        self.assertEqual(old,new)
        self.assertEqual(execution['device'],'cuda:0')
        self.assertEqual(execution['calibration_device'],'cpu')
        self.assertFalse(execution['amp']); self.assertFalse(execution['tf32'])
        self.assertNotEqual(cpu.SCHEMA,cuda.SCHEMA)
        cfg=cuda.load_config(CONFIG,allow_existing_output=True)
        plan=cuda.plan(cfg)
        self.assertEqual((plan['tasks'],plan['supervised_completion_fits']),(27,54))
        self.assertFalse(plan['real_fitting_ready'])

    def test_import_plan_without_numerical_dependencies(self):
        code = '''import sys
class Guard:
 def find_spec(self, fullname, *args):
  if fullname.split('.')[0] in {'torch','numpy','scipy','sklearn','mne'}:
   raise RuntimeError('numerical import forbidden: '+fullname)
sys.meta_path.insert(0,Guard())
from inm.task_driven_completion_cuda.protocol import load_config, plan, study_identity
cfg=load_config('configs/task-driven-completion-cuda.json',allow_existing_output=True)
assert plan(cfg)['tasks']==27
assert 'inm/task_driven_completion/completion.py' in study_identity(cfg)['source_files_sha256']
assert 'inm/task_driven_completion_cuda/execution.py' in study_identity(cfg)['source_files_sha256']
'''
        result=subprocess.run([sys.executable,'-c',code],cwd=ROOT,capture_output=True,text=True)
        self.assertEqual(result.returncode,0,result.stderr)

    def test_cpu_outputs_and_science_changes_refused(self):
        cfg=cuda.load_config(CONFIG,allow_existing_output=True)
        cfg['output_dir']=str(ROOT/'results/task-driven-completion-v1')
        # Protect the old namespace even if its directory is not created yet.
        with self.assertRaises(ValueError):
            cuda.validate_output_path(cfg)
        original=json.loads(CONFIG.read_text())
        original['protocol']['training']['learning_rate']=.002
        with tempfile.TemporaryDirectory() as directory:
            path=Path(directory)/'bad.json'; path.write_text(json.dumps(original))
            with self.assertRaises(ValueError):
                cuda.load_config(path)


if __name__ == '__main__':
    unittest.main()
