"""Read-only completed-cohort review; write only this review's derived receipt."""
import sys, json, hashlib, datetime, csv
from pathlib import Path
from collections import defaultdict
ROOT=Path(__file__).resolve().parents[3]
sys.path.insert(0,str(ROOT))
import numpy as np
import torch
torch.set_num_threads(1)
from inm.task_driven_completion_cuda.protocol import load_config,study_identity,tasks
from inm.task_driven_completion_cuda.study import _verify_complete_task,historical_hashes
from inm.completion_transformer.replay import verify_historical_task

def read(p): return json.loads(Path(p).read_text())
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def close(a,b): assert np.allclose(a,b,rtol=1e-12,atol=1e-12),(a,b)

cfg=load_config(ROOT/'configs/task-driven-completion-cuda-v2.json',allow_existing_output=True)
out=Path(cfg['output_dir']);state=ROOT/'.session-runs/task-driven-completion-cuda/experiments-v2'
identity=study_identity(cfg)
assert identity==read(out/'study-identity.json')==read(ROOT/'docs/task-driven-completion-cuda/frozen-real-identity-v2.json')
assert read(state/'status.json')['status']=='cohort_complete'
evidence=read(out/'report/evidence.json')
assert evidence['complete'] and evidence['valid_tasks']==27 and not evidence['issues'] and not evidence['synthetic_tasks_excluded']
assert evidence['study_id']==identity['study_id']
assert evidence==read(state/'cohort-report.stdout.log')
protection=read(ROOT/'.session-runs/task-driven-completion-cuda/repair-01/protected.json')
assert all(sha(ROOT/p)==h for p,h in protection.items())
baseline_hashes={str(p.relative_to(out)):sha(p) for p in out.rglob('*') if p.is_file()}
records=defaultdict(list);audited=0;fits=defaultdict(list);replay_errors=[];artifact_count=0
for index,spec in enumerate(tasks(cfg)):
    path=out/'tasks'/f"A{spec['subject']:02d}_seed_{spec['seed']}"
    task=_verify_complete_task(path,identity,synthetic=False)
    assert task['execution']==evidence['execution']
    assert (task['subject'],task['seed'])==(spec['subject'],spec['seed'])
    historical=verify_historical_task(cfg,spec['subject'],spec['seed'])
    assert task['historical_input_sha256']==historical_hashes(cfg,historical,spec['subject'])
    review=read(state/f'task-{index:02d}.review.json')
    assert review['status']=='accepted' and review['study_id']==identity['study_id']
    assert review['task_sha256']==sha(path/'task.json')
    audit_path=state/f'task-{index:02d}-audit.stdout.log'
    assert review['audit_sha256']==sha(audit_path)
    for command in ('fit_command','audit_command'):
        assert review[command]['exit_code']==0 and not review[command]['timed_out']
    audit=read(audit_path)
    assert audit['status']=='passed' and audit['replayed_cells']==105 and audit['new_fits']==0
    assert audit['study_id']==identity['study_id'] and audit['subject']==spec['subject'] and audit['seed']==spec['seed']
    assert all(audit[k] is True for k in ('exact_prediction_replay','backbone_matches_source','selected_states_loaded','independently_recomputed_metrics','independently_recomputed_contrasts'))
    assert audit['cuda_full_input_vs_cpu']['passed']
    audited+=audit['replayed_cells'];artifact_count+=len(task['artifacts'])
    replay_errors.append(task['replay']['cuda_full_input_vs_cpu']['max_abs_probability_error'])
    for strategy in ('tucker_learned','covariance_learned'):
        fits[strategy].append(task['fits'][strategy])
    for cell in task['cells']:
        with np.load(path/cell['artifact'],allow_pickle=False) as saved:
            p=saved['probabilities'].astype(np.float64);y=saved['labels'];pred=p.argmax(1)
            ba=sum(float((pred[y==c]==c).mean()) for c in range(4))/4
            ll=float(-np.log(np.clip(p[np.arange(len(y)),y],1e-12,1)).mean())
        close(ba,cell['balanced_accuracy']);close(ll,cell['log_loss'])
        for metric,value in [('balanced_accuracy',ba),('log_loss',ll)]:
            records[(spec['subject'],spec['seed'],cell['strategy'],cell['condition'],metric)].append(value)
    print(json.dumps({'task_index':index,'status':'verified'}),flush=True)

seed_values={k:float(np.mean(v)) for k,v in records.items()}
participant=defaultdict(list)
for (subject,seed,strategy,condition,metric),v in seed_values.items():
    participant[subject,strategy,condition,metric].append(v)
participant={k:float(np.mean(v)) for k,v in participant.items()}
cohort=defaultdict(list)
for (subject,strategy,condition,metric),v in participant.items(): cohort[strategy,condition,metric].append(v)
cohort={k:float(np.mean(v)) for k,v in cohort.items()}
for row in evidence['seed_conditions']:
    close(row['value'],seed_values[row['subject'],row['seed'],row['strategy'],row['condition'],row['metric']])
for row in evidence['participant_conditions']:
    close(row['value'],participant[row['subject'],row['strategy'],row['condition'],row['metric']])
for row in evidence['cohort_conditions']:
    close(row['value'],cohort[row['strategy'],row['condition'],row['metric']])
conditions=['random_static_16','dynamic_random_16','random_static_6','dynamic_random_6']
strategies=['zero','tucker_frozen','tucker_learned','covariance_frozen','covariance_learned']
means={s:{m:float(np.mean([cohort[s,c,m] for c in conditions])) for m in ['balanced_accuracy','log_loss']} for s in strategies}
for row in evidence['contrasts']:
    name=row['contrast'];pair=name.removeprefix('primary_').removeprefix('secondary_').split('_minus_');a,b=pair
    values=[float(np.mean([participant[i,a,c,'balanced_accuracy']-participant[i,b,c,'balanced_accuracy'] for c in conditions])) for i in range(1,10)]
    close(row['mean_gain'],np.mean(values))
    assert row['positive_participants']==sum(v>0 for v in values)
    rng=np.random.default_rng(20261005)
    close(row['ci_95'],np.quantile(np.mean(rng.choice(values,size=(2000,9),replace=True),axis=1),[.025,.975]))
    for item in evidence['participant_contrasts']:
        if item['contrast']==name: close(item['gain'],values[item['subject']-1])
for name in ['seed_conditions','participant_conditions','cohort_conditions','participant_contrasts']:
    rows=list(csv.DictReader((out/'report'/f'{name}.csv').open()))
    assert len(rows)==len(evidence[name])
    for a,b in zip(rows,evidence[name]):
        for k,v in b.items():
            if isinstance(v,(int,float)): close(float(a[k]),v)
            else: assert a[k]==str(v)
assert baseline_hashes=={str(p.relative_to(out)):sha(p) for p in out.rglob('*') if p.is_file()}
receipt={'verified_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'study_id':identity['study_id'],
 'status':'passed','real_tasks':27,'supervised_fits':54,'freshly_recomputed_prediction_cells':audited,
 'retained_exact_gpu_replay_audits_verified':27,'fresh_gpu_replays_this_review':0,'new_fits':0,
 'task_artifacts_checksum_verified':artifact_count,'protected_files_unchanged':len(protection),
 'all_study_files_unchanged':len(baseline_hashes),'source_config_packages_history_identity':'unchanged',
 'original_input_hashes':'verified for all tasks','metrics_and_hierarchical_aggregation':'independently recomputed',
 'bootstrap_intervals':'independently reproduced','degraded_means':means,'contrasts':evidence['contrasts'],
 'conditions':evidence['cohort_conditions'],'participant_contrasts':evidence['participant_contrasts'],
 'max_full_input_cpu_gpu_error':max(replay_errors),'fit_epochs':fits,'primary_screen_met':evidence['primary_screening_rule_met'],
 'limitations':evidence['limitations'],'study_files_sha256':baseline_hashes}
Path(__file__).with_name('verification.json').write_text(json.dumps(receipt,indent=2,sort_keys=True)+'\n')
print(json.dumps({k:v for k,v in receipt.items() if k not in ['study_files_sha256','conditions','participant_contrasts','fit_epochs']},indent=2))
